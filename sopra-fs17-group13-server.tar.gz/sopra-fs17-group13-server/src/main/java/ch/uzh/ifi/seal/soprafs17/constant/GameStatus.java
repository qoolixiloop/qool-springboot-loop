package ch.uzh.ifi.seal.soprafs17.constant;

public enum GameStatus {
	PENDING, STARTING, RUNNING, FINISHED
}
