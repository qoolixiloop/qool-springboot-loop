package ch.uzh.ifi.seal.soprafs17.constant;

import javax.persistence.Embeddable;

/**
 * Created by nairboon on 27.03.17.
 */
@Embeddable
public enum PlayerFieldColour {
    EMPTY, BLACK, WHITE, BROWN, GREY
}
