package ch.uzh.ifi.seal.soprafs17.gamelogic;

import ch.uzh.ifi.seal.soprafs17.entity.Move;

/**
 * Created by nairboon on 27.03.17.
 */
public interface MoveZone {
    boolean isCorrectZone(Move m);
}
