package ch.uzh.ifi.seal.soprafs17.gamelogic;

import ch.uzh.ifi.seal.soprafs17.constant.PlayerFieldColour;

/**
 * Created by Spasen on 06.04.17.
 */
public class PyramidField {

    public PlayerFieldColour playerColour = PlayerFieldColour.EMPTY;
    public int points;
}
