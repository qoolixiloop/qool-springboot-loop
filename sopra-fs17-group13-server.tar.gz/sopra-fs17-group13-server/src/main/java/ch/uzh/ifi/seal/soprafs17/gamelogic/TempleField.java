package ch.uzh.ifi.seal.soprafs17.gamelogic;

import ch.uzh.ifi.seal.soprafs17.constant.PlayerFieldColour;

/**
 * Created by Spasen on 06.04.17.
 */
public class TempleField {

    public PlayerFieldColour playerColour = PlayerFieldColour.EMPTY;
/*
 loads empty array with empty tags depending on
 how many numPlayers there are
*/





}
