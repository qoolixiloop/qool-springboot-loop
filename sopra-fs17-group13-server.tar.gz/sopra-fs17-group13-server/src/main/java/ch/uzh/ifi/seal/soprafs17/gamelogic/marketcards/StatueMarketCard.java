package ch.uzh.ifi.seal.soprafs17.gamelogic.marketcards;

/**
 * Created by Spasen on 19.04.17.
 */
public class StatueMarketCard extends MarketCard{

    public StatueMarketCard(int id) {
        super(Type.Statue, id);
    }

}
