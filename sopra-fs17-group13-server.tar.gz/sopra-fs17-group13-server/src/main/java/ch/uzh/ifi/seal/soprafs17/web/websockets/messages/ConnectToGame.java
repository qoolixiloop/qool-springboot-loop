package ch.uzh.ifi.seal.soprafs17.web.websockets.messages;

/**
 * Created by nairboon on 16.04.17.
 */
public class ConnectToGame {

    public Long gameId;
    public String user;
}
