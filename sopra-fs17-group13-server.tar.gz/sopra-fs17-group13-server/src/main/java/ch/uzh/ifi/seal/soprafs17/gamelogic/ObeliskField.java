package ch.uzh.ifi.seal.soprafs17.gamelogic;

import ch.uzh.ifi.seal.soprafs17.constant.PlayerFieldColour;

/**
 * Created by Spasen on 27.03.17.
 */
public class ObeliskField {


    public int amount;




    public PlayerFieldColour playerColour;


    public ObeliskField(PlayerFieldColour c){
        playerColour = c;

    }

}