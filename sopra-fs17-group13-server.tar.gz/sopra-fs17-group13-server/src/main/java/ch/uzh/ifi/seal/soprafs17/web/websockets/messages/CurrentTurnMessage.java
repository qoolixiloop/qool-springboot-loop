package ch.uzh.ifi.seal.soprafs17.web.websockets.messages;

/**
 * Created by Spasen on 27.04.17.
 */
public class CurrentTurnMessage {
    public String user;
}
