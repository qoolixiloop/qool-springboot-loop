package ch.uzh.ifi.seal.soprafs17.constant;

import java.util.Set;
import java.util.stream.Collector;

public enum UserStatus {
	ONLINE, OFFLINE;


}
